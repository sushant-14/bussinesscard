const { render } = require('ejs');
// model.js file import
const User = require("../models/user");

module.exports.home=function(req,res){
    // console.log(req.cookies);
    // res.cookie('user_id',25);
    User.find({},function(err,users){
        return res.render('home',{
            title:'home page is this',
            all_users:users,
            admin:"63e29cf0d1fe5732c9db1def"
        });
    })
}

module.exports.signUp=function(req,res){
    if(req.isAuthenticated()){
        return res.redirect('/users/about');
    }

    return res.render("user_sign_up",{
        title:"Sign Up | page"
    })
}

module.exports.signIn=function(req,res){
    if(req.isAuthenticated()){
        return res.redirect('/users/about');
    }
    return res.render("user_sign_in",{
        title:"Sign In | page"
    })
}

// module.exports.about=function(req,res){
//     if(req.cookies.user_id){
//         User.findById(req.cookies.user_id,function(err,user){
//             if(User){
//                 return res.render('about',{
//                     title:"about page is this",
//                     user:user
//                 })
//             }else{
//                 return res.redirect('/sign-in')
//             }
//         });
//     }else{
//         return res.redirect('/sign-in')
//     }
// }

module.exports.about=async function(req,res){
    try{
        let all_user=await User.find({})
        console.log(all_user,"all_user")

        let user= await User.findById(req.params.id)
        console.log(user,"user")
        return res.render('about',{
            title:"about page is this",
            profile_user:user,
            all_users:all_user
        });



    }catch(err){
        console.log('error',err);
        return;
    }
    
    // return res.render('about',{
    //     title:"about page is this"
    // })
}

module.exports.update=function(req,res){
    if(req.user.id == req.params.id){
        User.findByIdAndUpdate(req.params.id,req.body,function(err,user){
            return res.redirect('back');

        })
    }else{
        return res.status(401).send('Unauthorized')
    }
}
// module.exports.create=function(req,res){
//     console.log(req.body);
//     User.create({
//         email:req.body.email,
//         password:req.body.password,
//         name:req.body.name
//     },function(err,signup){
//         if(err){
//             console.log(`error in sign up ${err}`)
//             return;
//         }
//         console.log("sign up:",signup)
//         return res.redirect('back')
//     })
// }
module.exports.create=function(req,res){
    if (req.body.password != req.body.confirm_password){
        return res.redirect('back');
    }
    User.findOne({email:req.body.email},function(err,user){
        if(err){
            console.log("error in finding user signing up");
            return
        }
        if(!user){
            User.create(req.body,function(err,user){
                if(err){
                    console.log('error in creating');
                    return;
                }
                return res.redirect('/users/sign-in')
            })
        }
        else{
            return res.redirect('back')
        }
    })
}


// sign created session
// module.exports.createSession=function(req,res){
//     // STEP TO authenticate
//     // find the user
//     User.findOne({email:req.body.email},function(err,user){
//         if(err){console.log("error in finding user signin"); return}
//         // handel the user
//         if(user){
//             if(user.password != req.body.password){
//                 return res.redirect('back')
//             }
//             //  handel session
//             res.cookie('user_id',user.id)
//             return res.redirect('/about')
//         }else{
//             // handel user not found
//             return res.redirect('back')
//         }    
//     })
// }

// for passport
module.exports.createSession = function(req, res){
    return res.redirect('/')
}

module.exports.destroySession=function(req,res){
    // req.logout();
    // return res.redirect('/');
    req.logout(function(err) {
        if (err) { return next(err); }
        res.redirect('/');
      });
}
// app.post('/logout', function(req, res, next){
//     req.logout(function(err) {
//       if (err) { return next(err); }
//       res.redirect('/');
//     });
//   });

